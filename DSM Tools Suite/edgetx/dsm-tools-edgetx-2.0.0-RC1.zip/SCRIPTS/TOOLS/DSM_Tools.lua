-- TNS|DsmTools 2.0-RC1|TNE

local function run()
    return "/SCRIPTS/TOOLS/dsm-tools/main.lua"
end

return { run = run }