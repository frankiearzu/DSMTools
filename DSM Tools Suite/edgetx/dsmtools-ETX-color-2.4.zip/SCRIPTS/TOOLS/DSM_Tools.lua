-- TNS|DsmTools 2.4|TNE

local function run()
    return "/SCRIPTS/TOOLS/dsm-tools/main.lua"
end

return { run = run }