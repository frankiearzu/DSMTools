local toolName = "TNS|DSM Smart RX Tel v1.2|TNE"
local version  = "1.2"
---- #########################################################################                                                                  #
---- # License GPLv2: http://www.gnu.org/licenses/gpl-2.0.html               #
---- #                                                                       #
---- # This program is free software; you can redistribute it and/or modify  #
---- # it under the terms of the GNU General Public License version 2 as     #
---- # published by the Free Software Foundation.                            #
---- #                                                                       #
---- # This program is distributed in the hope that it will be useful        #
---- # but WITHOUT ANY WARRANTY; without even the implied warranty of        #
---- # MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         #
---- # GNU General Public License for more details.                          #
---- #                                                                       #
---- #########################################################################

------------------------------------------------------------------------------ 
-- Developer: Francisco Arzu

local TEXT_SIZE             = 0 -- NORMAL
local TEXT_SIZE_BIG         = MIDSIZE
local X_COL1_HEADER         = 6
local X_COL1_DATA           = 60
local X_COL2_HEADER         = 170
local X_COL2_DATA           = 220
local Y_LINE_HEIGHT         = 20
local Y_HEADER              = 0
local Y_DATA                = Y_HEADER + Y_LINE_HEIGHT*2 
local X_DATA_LEN            = 80 
local X_DATA_SPACE          = 5

local C_UP                  = CHAR_UP
local C_DOWN                = CHAR_DOWN

local MENU_MAX_PER_PAGE     = 7


local U8_NODATA             = 0xFF
local U16_NODATA            = 0xFFFF
local U32_NODATA            = 0xFFFFFFFF
local I8_NODATA             = 0x7f
local I16_NODATA            = 0x7fff

local STR_data              = {[0]=0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF, 0xFF, 0x0FF}

local I2C_FLITECTRL         = 0x05
local I2C_TEXT_GEN          = 0x0C
local I2C_ESC               = 0x20
local I2C_REMOTE_ID         = 0x27
local I2C_FP_BATT           = 0x34
local I2C_SMART_BAT         = 0x42
local I2C_QOS               = 0x7F


local function Unsigned_to_SInt16(value) 
  if value >= 0x8000 then  -- Negative value??
      return value - 0x10000
  end
  return value
end

local function STR_open(i2cId)
  --Init telemetry  (Spectrun Telemetry Raw STR)
  for i=0,15 do
    STR_data[i] = U8_NODATA
  end

  multiBuffer( 0, string.byte('S') )
  multiBuffer( 1, string.byte('T') )
  multiBuffer( 2, string.byte('R') ) 
  multiBuffer( 3, i2cId ) -- Monitor this teemetry data
  multiBuffer( 4, 0 ) -- Allow to get Data
end

local function STR_close()
  multiBuffer(0, 0) -- Destroy the STR header 
  multiBuffer(3, 0) -- Not requesting any Telementry ID
end

local function STR_isDataReady(i2cId) 
  if (multiBuffer(0)~=string.byte('S') or multiBuffer(3) ~= i2cId ) then -- First time run???
    STR_open(i2cId) -- I2C_ID 
  end

  if multiBuffer( 4 ) == i2cId then
    for i=0,15 do
      STR_data[0+i] = multiBuffer(4+i)
    end
    multiBuffer( 4, 0 ) -- Allow to get Data
    return true
  end
  return false
end

local function STR_DATA_I8(p)
  local val = STR_data[p]
  if (val == I8_NODATA) then return nil else return val end
end

local function STR_DATA_U8(p)
  local val = STR_data[p]
  if (val == U8_NODATA) then return nil else return val end
end

local function STR_DATA_I16LE(p)
     local val = STR_data[p] + bit32.lshift(STR_data[p+1], 8)
     if (val == I16_NODATA) then return nil else return Unsigned_to_SInt16(val) end
end

local function STR_DATA_U16LE(p)
  local val = STR_data[p] + bit32.lshift(STR_data[p+1], 8)
  if (val == U16_NODATA) then return nil else return val end
end

local function STR_DATA_U16(p)
  local val = bit32.lshift(STR_data[p], 8) + STR_data[p+1]
  if (val == U16_NODATA) then return nil else return val end
end

local function STR_DATA_I16(p)
  local val = bit32.lshift(STR_data[p], 8) + STR_data[p+1]
  if (val == I16_NODATA) then return nil else return val end
end

local function STR_DATA_U32(p)
  local val = bit32.lshift(STR_data[p], 24) + bit32.lshift(STR_data[p+1], 16) + 
              bit32.lshift(STR_data[p+2], 8)  + STR_data[p+3]
  if (val == U32_NODATA) then return nil else return val end
end

local function STR_DATA_U32LE(p)
  local val = bit32.lshift(STR_data[p+3], 24) + bit32.lshift(STR_data[p+2], 16) + 
              bit32.lshift(STR_data[p+1], 8)  + STR_data[p]
  if (val == U32_NODATA) then return nil else return val end
end

local function STR_DATA_STR(p,len,breakOnZero)
  local line=""
  for i=0,len-1 do
    local ch = STR_data[ p + i ]
    if (ch==0 and breakOnZero) then break; end
    if (ch<32 or ch > 126) then line=line.."."
    else 
      line = line .. string.char(ch)
    end
  end
  return line
end

local function STR_DATA_HEX(p,len)
  local line=""
  for i=0,len-1 do
    local ch = STR_data[ p + i ]
    line = line .. string.format("%02X",ch).." "
  end
  return line
end

local function STR_Disp(val, postfix)
  if (val == nil) then return "---" end
  return val .. (postfix or "")
end

local function STR_DispFloat1(val,postfix)
  if (val == nil) then return "---" end
  return string.format("%0.1f",val/10) .. (postfix or "")
end


local function comma(formatted)
  if (formatted==nil) then return nil end
  local k=1
  while k ~= 0 do
    formatted, k = string.gsub(formatted, "^(-?%d+)(%d%d%d)","%1,%2")
  end
  return formatted
end

-----------------------------------------------------------------------------------

local QOS_Title  = {[0]="A:", "B:", "L:", "R:", "F:", "H:"}
local QOS_Value  = {[0]="--","--","--","--","--",0,"--"}

local function drawFlightLogScreen(event)
  
  if  STR_isDataReady(I2C_QOS) then
    QOS_Value[0] = STR_Disp(STR_DATA_U16(2)) -- A
    QOS_Value[1] = STR_Disp(STR_DATA_U16(4)) -- B
    QOS_Value[2] = STR_Disp(STR_DATA_U16(6)) -- L
    QOS_Value[3] = STR_Disp(STR_DATA_U16(8)) -- R 
    QOS_Value[4] = STR_Disp(STR_DATA_U16(10)) -- F
    QOS_Value[5] = STR_DATA_U16(12) or 0 -- H
    local bat = STR_DATA_U16(14)
    if (bat ~= nil) then bat = string.format("%0.2f", bat/100) else bat = "--" end
    QOS_Value[6] = bat
  end

  -- draw labels and params on screen
  
  lcd.clear()
  lcd.drawText (X_COL1_HEADER, Y_HEADER, "Flight Log", TEXT_SIZE + INVERS)

  local activeParam = QOS_Value[5] - 1 -- H 

  local y = Y_LINE_HEIGHT+Y_DATA

  for iParam=0,3 do   -- A,B,L,R 
    -- highlight selected parameter  (rund)
    local attr = ((activeParam % 4)==iParam) and INVERS or 0

    lcd.drawText (X_COL1_HEADER, y, QOS_Title[iParam], TEXT_SIZE)
    
    -- Values
    local val = QOS_Value[iParam] 
    if (val~=0x4000) then  -- Active value
        lcd.drawText (X_COL1_DATA + X_DATA_LEN, y, val, attr + TEXT_SIZE + RIGHT)
    end

    y = y + Y_LINE_HEIGHT
  end

  y = Y_LINE_HEIGHT+Y_DATA
  for iParam=4,5 do  -- F, H
    lcd.drawText (X_COL2_HEADER, y, QOS_Title[iParam], TEXT_SIZE_BIG)
    lcd.drawText (X_COL2_DATA + X_DATA_LEN, y, QOS_Value[iParam], TEXT_SIZE_BIG + RIGHT)
    y = y + Y_LINE_HEIGHT*2
  end

  -- Bat 
  y = y + Y_LINE_HEIGHT
  lcd.drawText (X_COL2_HEADER, y, "Bat:", TEXT_SIZE)
  lcd.drawText (X_COL2_DATA + X_DATA_LEN, y, QOS_Value[6], TEXT_SIZE + RIGHT)
  lcd.drawText (X_COL2_DATA + X_DATA_LEN + X_DATA_SPACE, y, " v", TEXT_SIZE)
end
-----------------------------------------------------------------------------------

local AS3X_Flags = nil
local AS3X_State = nil
local AS3X_FlagsMsg=""
local AS3X_FmMsg="--"

local AS3X_Data = {[0]="-","-","-","-","-","-",
                      "-","-","-","-","-","-",
                      "-","-","-","-","-","-"}

local function drawAS3XSettings(event, page)

  if  STR_isDataReady(I2C_FLITECTRL) then
    AS3X_FlagsMsg=""

    AS3X_Flags = STR_DATA_U8(2)
    AS3X_State = STR_DATA_U8(3)

    local fm = bit32.band(STR_data[4],0xF)
    local axis = bit32.band(STR_data[5],0xF)  -- 0=Gains,1=Headings,2=Angle Limits (cointinus iterating to provide all values)
  
    if (fm ~= 0x0E) then
      local separator=""
      
      AS3X_FmMsg = ""..(fm+1)
      -- flags bits:  Safe Envelop, ?, Angle Demand, Stab 
      if (bit32.band(AS3X_Flags,0x1)~=0) then AS3X_FlagsMsg=AS3X_FlagsMsg.."AS3X Stab"; separator=", " end
      -- This one, only one should show
      if (bit32.band(AS3X_Flags,0x2)~=0) then AS3X_FlagsMsg=AS3X_FlagsMsg..separator.."Safe Level" 
      elseif (bit32.band(AS3X_Flags,0x8)~=0) then AS3X_FlagsMsg=AS3X_FlagsMsg..separator.."Safe Envelope" 
      elseif (bit32.band(AS3X_Flags,0x4)~=0) then AS3X_FlagsMsg=AS3X_FlagsMsg..separator.."Heading" end
  
      --axis: 0=Gains+Headings (RG,PG,YG,RH,PH,YH), 1=Safe Gains (R,P,Y),2=Angle Limits(L,R,U,D) 
      --Constantly changing from 0..2 to represent different data, thats why we have to store the values
      --in a script/global variable, and not local to the function
      local s = axis*6
      for i=0,5 do 
        AS3X_Data[s+i] = STR_Disp(STR_DATA_U8(6+i))
      end
    else
      -- FM==0xE
      if (AS3X_State==0) then AS3X_FlagsMsg="Initializing.."; AS3X_FmMsg="--"
      elseif (AS3X_State==2) then AS3X_FlagsMsg="Error: FM-Switch-Range" end
    end  
  end
  
  lcd.clear()
  if (page==1) then
    lcd.drawText (1,0, "AS3X Settings", TEXT_SIZE + INVERS)
  else
    lcd.drawText (1,0, "SAFE Limits", TEXT_SIZE + INVERS)
  end

  local y = Y_DATA
  -- Flight Mode
  lcd.drawText (X_COL1_HEADER,y, "FM: "..AS3X_FmMsg, TEXT_SIZE)
  lcd.drawText (X_COL1_DATA+X_DATA_LEN*0.4,y, "Flags: "..STR_Disp(AS3X_Flags), TEXT_SIZE)
  lcd.drawText (X_COL2_HEADER+X_DATA_LEN*0.7,y, "State: "..STR_Disp(AS3X_State), TEXT_SIZE)

  y = y + Y_LINE_HEIGHT
  lcd.drawText (X_COL1_HEADER,y, AS3X_FlagsMsg, TEXT_SIZE)

  y = y + Y_LINE_HEIGHT

  if (fm == 0xE) then
    return
  end

  if (page==1) then
    lcd.drawText (X_COL1_HEADER+X_DATA_LEN*0.3,y, "AS3X Gains", TEXT_SIZE+BOLD)
    lcd.drawText (X_COL2_HEADER+X_DATA_LEN*0.3,y, "AS3X Headings", TEXT_SIZE+BOLD)
    
    y = y + Y_LINE_HEIGHT
    lcd.drawText (X_COL1_HEADER,y, "Roll:", TEXT_SIZE)
    lcd.drawText (X_COL1_DATA+X_DATA_LEN,y, AS3X_Data[0], TEXT_SIZE + RIGHT) -- Roll G 
    lcd.drawText (X_COL2_DATA+X_DATA_LEN,y, AS3X_Data[3], TEXT_SIZE + RIGHT) -- Roll H 

    y = y + Y_LINE_HEIGHT
    lcd.drawText (X_COL1_HEADER,y, "Pitch:", TEXT_SIZE)
    lcd.drawText (X_COL1_DATA+X_DATA_LEN,y, AS3X_Data[1], TEXT_SIZE + RIGHT)  -- Pitch G
    lcd.drawText (X_COL2_DATA+X_DATA_LEN,y, AS3X_Data[4], TEXT_SIZE + RIGHT) -- Pitch H 

    y = y + Y_LINE_HEIGHT
    lcd.drawText (X_COL1_HEADER,y, "Yaw:", TEXT_SIZE)
    lcd.drawText (X_COL1_DATA+X_DATA_LEN,y, AS3X_Data[2], TEXT_SIZE + RIGHT) -- Yaw G
    lcd.drawText (X_COL2_DATA+X_DATA_LEN,y, AS3X_Data[5], TEXT_SIZE + RIGHT) -- Yaw H
  end


  if (page==2) then
    local x_data1 = X_COL1_DATA+X_DATA_LEN
    local x_data2 = X_COL2_HEADER+X_DATA_LEN*1.6

    lcd.drawText (X_COL1_HEADER+X_DATA_LEN*0.3,y, "SAFE Gains", TEXT_SIZE+BOLD)
    lcd.drawText (X_COL2_HEADER+X_DATA_LEN*0.1,y, "Angle Limits", TEXT_SIZE+BOLD)
  
    y = y + Y_LINE_HEIGHT
    lcd.drawText (X_COL1_HEADER,y, "Roll:", TEXT_SIZE)
    lcd.drawText (x_data1,y, AS3X_Data[6], TEXT_SIZE + RIGHT)

    lcd.drawText (X_COL2_HEADER,y, "Roll R:", TEXT_SIZE)
    lcd.drawText (x_data2,y, AS3X_Data[12], TEXT_SIZE + RIGHT)


    y = y + Y_LINE_HEIGHT
    lcd.drawText (X_COL1_HEADER,y, "Pitch:", TEXT_SIZE)
    lcd.drawText (x_data1,y,AS3X_Data[7], TEXT_SIZE + RIGHT)

    lcd.drawText (X_COL2_HEADER,y, "Roll L:", TEXT_SIZE)
    lcd.drawText (x_data2,y,AS3X_Data[13], TEXT_SIZE + RIGHT)


    y = y + Y_LINE_HEIGHT
    lcd.drawText (X_COL1_HEADER,y, "Yaw:", TEXT_SIZE)
    lcd.drawText (x_data1,y, AS3X_Data[8], TEXT_SIZE + RIGHT)

    lcd.drawText (X_COL2_HEADER,y, "Pitch U:", TEXT_SIZE)
    lcd.drawText (x_data2,y, AS3X_Data[14], TEXT_SIZE + RIGHT)

    y = y + Y_LINE_HEIGHT
    lcd.drawText (X_COL2_HEADER,y, "Pitch D:", TEXT_SIZE)
    lcd.drawText (x_data2,y, AS3X_Data[15], TEXT_SIZE + RIGHT)
  end
end

local function drawAS3XSettingsP1(event)
  drawAS3XSettings(event, 1)
end

local function drawAS3XSettingsP2(event)
  drawAS3XSettings(event, 2)
end

-----------------------------------------------------------------------------------

local ESC_Title= {[0]="","RPM:","Volts:","Motor:","Mot Out:","Throttle:","FET Temp:", "BEC V:", "BEC T:", "BEC A:"}
local ESC_uom  = {[0]="",""," V"," A"," %"," %"," C", " V"," C"," A"}
local ESC_Value= {[0]=nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil}
local ESC_Min  = {[0]=nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil}
local ESC_Max  = {[0]=nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil}

local function drawESCStatus(event)
  local function setDataMinMax(p,val,format)
    if (val==nil) then return end;

    ESC_Value[p]=val
    if (ESC_Min[p]==nil) then ESC_Min[p]=val else ESC_Min[p] = math.min(ESC_Min[p],val) end
    if (ESC_Max[p]==nil) then ESC_Max[p]=val else ESC_Max[p] = math.max(ESC_Max[p],val) end
  end

  if  STR_isDataReady(I2C_ESC) then
      -- Big Endian
      local rpm = STR_DATA_U16(2)  -- RPM * 10
      local volts = STR_DATA_U16(4)  -- Volts / 100
      local temp = STR_DATA_U16(6)  -- Temp FET / 10
      local curr = STR_DATA_U16(8)  -- Curr / 100
      local tempB = STR_DATA_U16(10)  -- Temp BEC / 10 
      local currB = STR_DATA_U8(12) -- Curr BEC / 10
      local voltsB = STR_DATA_U8(13) -- Volts BEC / 20
      local outP = STR_DATA_U8(14) -- % Output / 2
      local thrP = STR_DATA_U8(15) -- Throttle %  / 2

      if (rpm) then setDataMinMax(1,rpm*10) end -- RPM
      if (volts) then setDataMinMax(2,volts/100,"%0.2f") end -- Volts
      if (curr) then setDataMinMax(3,curr/100,"%0.2f") end -- Curr
      if (outP) then setDataMinMax(4,outP/2) end -- Output
      if (thrP) then setDataMinMax(5,thrP/2) end -- Throttle
      if (temp) then setDataMinMax(6,temp/10) end -- Temp FET
      if (voltsB) then setDataMinMax(7,voltsB/20,"%0.2f") end -- Volts BEC
      if (tempB) then setDataMinMax(8,tempB/10) end -- Temp BEC
      if (currB) then setDataMinMax(9,currB/10) end -- Cur BEC
  end

  lcd.clear() 
  lcd.drawText (1,0, "ESC", TEXT_SIZE+INVERS)

  local y = 0
  local x_data = X_COL1_DATA+X_DATA_LEN*1.5
  local x_data2 = X_COL2_DATA+X_DATA_LEN*0.5
  local x_data3 = x_data2 + X_DATA_LEN*0.8

  local fontD = TEXT_SIZE + RIGHT
  local fontH1 = TEXT_SIZE + BOLD + RIGHT

  lcd.drawText (x_data,y , "Status", fontH1)
  lcd.drawText (x_data2,y, "Min", fontH1)
  lcd.drawText (x_data3,y, "Max", fontH1)
  
  y = Y_DATA
  for i=1,9 do
      lcd.drawText (X_COL1_HEADER,y, ESC_Title[i], TEXT_SIZE)

      local val = ESC_Value[i]
      local min = ESC_Min[i]
      local max = ESC_Max[i]
      if (i==1) then -- RPM
        val = comma(val)
        min = comma(min)
        max = comma(max)
      end
      lcd.drawText (x_data,y, STR_Disp(val), fontD)
      lcd.drawText (x_data,y, ESC_uom[i], TEXT_SIZE)
      lcd.drawText (x_data2,y, STR_Disp(min), fontD)
      lcd.drawText (x_data3,y, STR_Disp(max), fontD)
      y = y + Y_LINE_HEIGHT
  end
end

-----------------------------------------------------------------------------------
local BAT_Title   ={[0]="","Bat:","Curr:", "Temp:", "Used:", "Rem :", "RX:"}
local BAT_uom     ={[0]="","V","mA","C","mAh","%","V"}
local BAT_Values  ={[0]=nil,"--","--","--","--","--","--"}
local BAT_Cells   ={[0]=0,0,0,0,0,0,0,0,0,0,0,0}

local function drawBATStatus(event)
  local function getVTotal()
    local VTotal=0
    for i=0,11 do
        VTotal = VTotal + BAT_Cells[i]
    end
    return VTotal
  end

  if  STR_isDataReady(I2C_SMART_BAT) then
    -- Big Endian
    local chType = STR_data[2]
    local msgType = bit32.band(chType,0xF0)
  
    if (msgType==0x00) then -- Battery Real Time
      local temp   = STR_DATA_I8(3)   -- Temp C
      local curr   = STR_DATA_U32LE(4)  -- Curr (mA)
      local usage  = STR_DATA_U16LE(8)  -- Usage (mAh)
      local minCell= STR_DATA_U16LE(10) -- MinCell (mV)
      local maxCell= STR_DATA_U16LE(12) -- MaxCell (mV)

      BAT_Values[2] = comma(curr or 0)
      BAT_Values[3] = STR_Disp(temp)
      BAT_Values[4] = comma(usage or 0)
      BAT_Values[5] = "--"

      local RX_Volts = getValue("A2") or 0 -- RX
      BAT_Values[6] = string.format("%0.2f",RX_Volts)
    elseif (msgType==0x10) then -- Cell 1-6
      local temp   = STR_DATA_I8(3)   -- Temp C
      for i=0,5 do
        BAT_Cells[i] = (STR_DATA_U16LE(4+i*2) or 0) / 1000   -- Usage (mV)
      end
      BAT_Values[3] = STR_Disp(temp)
    elseif (msgType==0x20) then -- Cell 7-12
      local temp   = STR_DATA_I8(3)   -- Temp C
      for i=0,5 do
        BAT_Cells[6+i] = (STR_DATA_U16LE(4+i*2) or 0) / 1000 -- Usage (mV)
      end
      BAT_Values[3] = STR_Disp(temp)
    end

    local vTotal = getVTotal()
  
    --if (vTotal==0) then -- No Inteligent Battery,use intelligent ESC if any
    --  local ESC_Volts = getValue("EVIN") or 0 -- Volts
    --  local ESC_Current = getValue("ECUR") or 0 -- Current
    --
    --  vTotal = ESC_Volts
    --  BAT_Values[2] = string.format("%d",ESC_Current * 1000)
    --end

    BAT_Values[1] = string.format("%0.2f",vTotal)
  end

  lcd.clear()
  lcd.drawText (1,0, "Battery Stats", TEXT_SIZE+INVERS)
  
  local y = Y_DATA
  local x_data = X_COL1_DATA+X_DATA_LEN+X_DATA_SPACE*3
  for i=1,6 do
      lcd.drawText (X_COL1_HEADER, y, BAT_Title[i], TEXT_SIZE + BOLD)
      lcd.drawText (x_data, y, BAT_Values[i], TEXT_SIZE + RIGHT)
      lcd.drawText (x_data+X_DATA_SPACE, y, BAT_uom[i], TEXT_SIZE)
      y = y + Y_LINE_HEIGHT
  end

  y = Y_DATA
  x_data = X_COL2_DATA+X_DATA_LEN+X_DATA_SPACE*5
  for i=0,8 do
      if ((BAT_Cells[i] or 0) > 0) then
        lcd.drawText (X_COL2_HEADER+X_DATA_LEN/2,y, "Cel "..(i+1)..":", TEXT_SIZE + BOLD)
        lcd.drawText (x_data,y, string.format("%2.2f",BAT_Cells[i]), TEXT_SIZE + RIGHT)
        lcd.drawText (x_data+X_DATA_SPACE,y, "V", TEXT_SIZE)
      end
      y = y + Y_LINE_HEIGHT
  end
end
-----------------------------------------------------------------------------------
local TG_LineText = {nil}
local function drawTextGen(event)
  if event == EVT_VIRTUAL_EXIT then -- Exit?? Clear menu data
    STR_close()
    TG_LineText = {nil}
    return
  end

  -- Proces TEXT GEN Telementry message
  if STR_isDataReady(I2C_TEXT_GEN) then -- Specktrum Telemetry ID of data received
    local instanceNo = STR_data[1]
    
    -- LineNo: 0 = title, 1-8 for general, 254 = Refresh backlight, 255 = Erase all text on screen
    local lineNo = STR_data[2]

    if (lineNo==254) then
      -- Backlight??
    elseif (lineNo==255) then 
        TG_LineText = {nil}
    else 
      local line = ""
      for i=0,12 do
        line = line .. string.char(STR_data[ 3 + i ])
      end
      TG_LineText[lineNo]=line
    end
  end

  lcd.clear()
  local y = Y_DATA
  local x = X_COL1_HEADER
  local hAttr = TEXT_SIZE + INVERS + BOLD

  if (LCD_H <= 64) then 
    -- Need to be able to show 8 lines of data + heather
    -- show header on the right hand side to gain 1 line
    x = 128
    y = 0
    hAttr = hAttr + RIGHT
  else
    y = Y_DATA + Y_LINE_HEIGHT
  end

  lcd.drawText (x,0, "TextGen", hAttr)
  if (TG_LineText[0]) then   -- Header
    lcd.drawText (x,Y_LINE_HEIGHT, TG_LineText[0], hAttr)
  end

  -- Menu lines
  
  for i=1,8 do
    if (TG_LineText[i]) then
      lcd.drawText (X_COL1_HEADER,y,  TG_LineText[i], TEXT_SIZE)
    end
    y = y + Y_LINE_HEIGHT
  end
end

-----------------------------------------------------------------------------------

local FP_Title= {[0]="Curr:","Used:","Temp:"}
local FP_uom  = {[0]=" A"," mAh"," C"}
local FP_Value= {[0]="-","-","-","-","-","-"}

local function drawFlightPackEnergyScreen(event)
  if event == EVT_VIRTUAL_EXIT then -- Exit?? Clear menu data
      STR_close()
      return
  end

  if STR_isDataReady(I2C_FP_BATT) then -- Specktrum Telemetry ID of data received
    -- Little Endian
    FP_Value[0] =  STR_DispFloat1(STR_DATA_I16LE(2)) --Curr 1
    FP_Value[1] =  STR_Disp(STR_DATA_I16LE(4)) --Used 1
    FP_Value[2] =  STR_DispFloat1(STR_DATA_I16LE(6)) --Temp 1

    FP_Value[3] =  STR_DispFloat1(STR_DATA_I16LE(8)) -- Curr 2
    FP_Value[4] =  STR_Disp(STR_DATA_I16LE(10)) -- Used 2
    FP_Value[5] =  STR_DispFloat1(STR_DATA_I16LE(12)) -- Temp 2
  end

  -- draw labels and params on screen
  local y = Y_HEADER
  local attrH2= TEXT_SIZE + RIGHT + INVERS
  local attrD = TEXT_SIZE + RIGHT

  lcd.clear()
  lcd.drawText (X_COL1_HEADER, y, "Flight Pack", TEXT_SIZE + INVERS)

  y = y + Y_LINE_HEIGHT + Y_LINE_HEIGHT
  lcd.drawText (X_COL1_DATA+X_DATA_LEN, y, "Batt 1", attrH2)
  lcd.drawText (X_COL2_HEADER+X_DATA_LEN, y, "Batt 2", attrH2)

  y = y + Y_LINE_HEIGHT

  for i=0,2 do
    lcd.drawText (X_COL1_HEADER, y, FP_Title[i], TEXT_SIZE)

    lcd.drawText (X_COL1_DATA + X_DATA_LEN, y, FP_Value[i], attrD)
    lcd.drawText (X_COL1_DATA + X_DATA_LEN, y, FP_uom[i], TEXT_SIZE)

    lcd.drawText (X_COL2_HEADER + X_DATA_LEN, y, FP_Value[i+3], attrD)
    lcd.drawText (X_COL2_HEADER + X_DATA_LEN, y, FP_uom[i], TEXT_SIZE)
    y = y + Y_LINE_HEIGHT
  end
end

-----------------------------------------------------------------------------------

--local FP_Title= {[0]="Curr:","Used:","Temp:"}
--local FP_uom  = {[0]=" A"," mAh"," C"}
--local FP_Value= {[0]="-","-","-","-","-","-"}

local function drawGPSScreen(event)
  if event == EVT_VIRTUAL_EXIT then -- Exit?? Clear menu data
      STR_close()
      return
  end

  -- draw labels and params on screen
  local y = Y_HEADER
  local attrH2= TEXT_SIZE + RIGHT + INVERS
  local attrD = TEXT_SIZE + RIGHT

  lcd.clear()
  lcd.drawText (X_COL1_HEADER, y, "GPS", TEXT_SIZE + INVERS)

  y = y + Y_LINE_HEIGHT + Y_LINE_HEIGHT


  y = y + Y_LINE_HEIGHT

end

-----------------------------------------------------------------------------------
local RID_OwnerInfo = ""
local RID_UAS_ID = ""
local RID_Status = 0

local OID_L00=""
local OID_L20=""
local OID_L40=""

local UAS_L60=""
local UAS_L80=""

local DEV_LA0_S=""
local DEV_LA0_H=""
local DEV_MODEL=""

local function drawRemoteIDScreen(event)
  if event == EVT_VIRTUAL_EXIT then -- Exit?? Clear menu data
      STR_close()
      return
  end

  if STR_isDataReady(I2C_REMOTE_ID) then -- Specktrum Telemetry ID of data received
      RID_Status = STR_DATA_I8(2)
      local lineType = STR_DATA_I8(3)
      local line = STR_DATA_STR(4,12,true)
  
      if (lineType == 0x00) then OID_L00 = line
      elseif (lineType == 0x20) then OID_L20 = line
      elseif (lineType == 0x40) then OID_L40 = line
      elseif (lineType == 0x60) then UAS_L60 = line
      elseif (lineType == 0x80) then UAS_L80 = line
      elseif (lineType == 0xA0) then 
        DEV_LA0_S = STR_DATA_STR(4,12,false)
        DEV_LA0_H = STR_DATA_HEX(4,12,false)
        DEV_MODEL = STR_DATA_STR(9,7,true)
      end

      RID_OwnerInfo = OID_L00 .. OID_L20 .. OID_L40
      RID_UAS_ID =  UAS_L60 .. UAS_L80
  end

  local RID_OWNER_ID = string.sub(RID_OwnerInfo,19)
  local DEV_SERIAL = string.sub(RID_OwnerInfo,0,18)

  -- draw labels and params on screen
  local y = Y_HEADER
  local attrH2= TEXT_SIZE + INVERS
  local attrD = TEXT_SIZE 

  lcd.clear()
  lcd.drawText (X_COL1_HEADER, y, "RemoteID", TEXT_SIZE + INVERS)

  y = y + Y_LINE_HEIGHT + Y_LINE_HEIGHT
  lcd.drawText (X_COL1_HEADER, y, "OWNER_INFO", attrH2)
  lcd.drawText (X_COL1_DATA*2, y, RID_OwnerInfo, attrD)
  y = y + Y_LINE_HEIGHT

  lcd.drawText (X_COL1_HEADER, y, "UAS_ID", attrH2)
  lcd.drawText (X_COL1_DATA*2, y, RID_UAS_ID, attrD)
  y = y + Y_LINE_HEIGHT

  lcd.drawText (X_COL1_HEADER, y, "DEV_INFO", attrH2)
  lcd.drawText (X_COL1_DATA*2, y, DEV_LA0_S, attrD)
  y = y + Y_LINE_HEIGHT
  lcd.drawText (X_COL1_DATA*2, y, "Hex:"..DEV_LA0_H, attrD)

  y = y + Y_LINE_HEIGHT
  lcd.drawText (X_COL1_HEADER, y, "Flight Status :"..RID_Status, attrD)
  y = y + Y_LINE_HEIGHT
  lcd.drawText (X_COL1_HEADER, y, "Dev Model : "..DEV_MODEL, attrD)
  y = y + Y_LINE_HEIGHT
  lcd.drawText (X_COL1_HEADER, y, "Dev Serial : "..DEV_SERIAL, attrD)
  y = y + Y_LINE_HEIGHT
  lcd.drawText (X_COL1_HEADER, y, "Owner ID : "..RID_OWNER_ID, attrD)


  
end
-----------------------------------------------------------------------------------

local MENU_ItemHighlight = 1
local MENU_Offeset       = 0
local MENU_ItemSelected  = 0
local MENU_ItemTitle     = {[0]="Main", "Flight Log", "AS3X Settings", "SAFE Limits", "ESC Status", "Battery Status",
                                "Flight Pack", "GPS", "RemoteID", "TextGen"}

local function drawMainScreen(event) 
  lcd.clear()
  lcd.drawText (X_COL1_HEADER, Y_HEADER, "Main Tel (Smart RXs) v"..version, TEXT_SIZE + INVERS)

  local x = X_COL1_DATA * 0.5

  for iParam=1 + MENU_Offeset, #MENU_ItemTitle do    
    -- highlight selected parameter
    local attr = (MENU_ItemHighlight==iParam) and INVERS or 0
    -- set y draw coord
    local y = (iParam-MENU_Offeset)*Y_LINE_HEIGHT+Y_DATA 
    
    -- labels
    local val = MENU_ItemTitle[iParam]
    lcd.drawText (x, y, val, attr + TEXT_SIZE)

    if ((iParam == MENU_Offeset +  MENU_MAX_PER_PAGE) and (iParam < #MENU_ItemTitle)) then 
      lcd.drawText (X_COL1_HEADER, y, C_DOWN, TEXT_SIZE)
      break 
    elseif (iParam == MENU_Offeset+1 and MENU_Offeset > 0) then
      lcd.drawText (X_COL1_HEADER, y, C_UP, TEXT_SIZE)
    end
  end

  if event == EVT_VIRTUAL_PREV then
    if (MENU_ItemHighlight>1) then 
      MENU_ItemHighlight = MENU_ItemHighlight - 1 

      if (MENU_ItemHighlight <= MENU_Offeset) then
        MENU_Offeset = MENU_Offeset - 1
      end
    end
  elseif event == EVT_VIRTUAL_NEXT then
    if (MENU_ItemHighlight<#MENU_ItemTitle) then 
      MENU_ItemHighlight = MENU_ItemHighlight + 1 

      if (MENU_ItemHighlight > MENU_Offeset + MENU_MAX_PER_PAGE) then
        MENU_Offeset = MENU_Offeset + 1
      end
    end
  elseif event == EVT_VIRTUAL_ENTER then
    MENU_ItemSelected = MENU_ItemHighlight
  end
end


local pageDraw  = {[0]=drawMainScreen, drawFlightLogScreen, drawAS3XSettingsP1, drawAS3XSettingsP2, 
                       drawESCStatus, drawBATStatus, 
                       drawFlightPackEnergyScreen, drawGPSScreen, drawRemoteIDScreen, 
                       drawTextGen }

local function run_func(event)
  if event == nil then
    error("Cannot be run as a model script!")
    return 2
  end

  -- draw specific page 
  pageDraw[MENU_ItemSelected](event)

  if event == EVT_VIRTUAL_EXIT then
    if (MENU_ItemSelected==0) then return 1 end  -- on Main?? Exit Script 
    MENU_ItemSelected = 0  -- any page, return to Main 
  end

  return 0
end

local function init_func()

  if (LCD_W <= 128 or LCD_H <=64) then -- Smaller Screens 
    TEXT_SIZE             = SMLSIZE 
    TEXT_SIZE_BIG         = DBLSIZE
    X_COL1_HEADER         = 1
    X_COL1_DATA           = 20

    X_COL2_HEADER         = 60
    X_COL2_DATA           = 90

    X_DATA_LEN            = 28 
    X_DATA_SPACE          = 1


    Y_LINE_HEIGHT         = 8
    Y_DATA                = Y_HEADER + Y_LINE_HEIGHT

    C_UP                 = "^"
    C_DOWN               = "v"

    MENU_MAX_PER_PAGE    = 5

  end
end

return { run=run_func,  init=init_func  }
