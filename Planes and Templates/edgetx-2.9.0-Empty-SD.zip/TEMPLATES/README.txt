User created model templates and template packs go in this directory.
