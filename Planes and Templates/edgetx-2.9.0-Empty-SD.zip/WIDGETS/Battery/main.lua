-- EdgeTX widget by Mika Korhonen (Spider)
-- V 2.1, 2023/04/17

local version = "BatteryV2"

local options = {
  { "BattSensor", SOURCE, 1 },
  { "Cells", VALUE, 3, 1, 12 },
  { "CellMax", VALUE, 420, 400, 435 },
  { "CellMin", VALUE, 360, 250, 380 },
  { "Alarm", BOOL, 1 }
}

-- Beep Battery Low Warning
local function batteryWarning(widget)
  if widget.options.Alarm == 1 and widget.bt < widget.CellMin or widget.bt > widget.CellMax then
    if getTime() >= widget.waitTime then
      widget.waitTime = getTime() + 200
	  playTone(2500, 200, 100, 0, 0)
	  playTone(2500, 200, 0, 0, 0)
    end
  end
end

local function create(zone, options)
  local widget = {
    zone = zone,
    options = options,
    waitTime = getTime(),
    bt = 0,
    CellMax = 0,
	CellMin = 0,
	picture = {}
  }
  local path = "/WIDGETS/Battery/"
  -- ToDo Dynamic loading Of Pictures To Reduse Memory Usage
  widget.picture[42] = Bitmap.open(path.."battery_42.png")
  widget.picture[56] = Bitmap.open(path.."battery_56.png")
  widget.picture[84] = Bitmap.open(path.."battery_84.png")
  widget.picture[169] = Bitmap.open(path.."battery_169.png")
  widget.CellMax = (widget.options.CellMax / 100) * widget.options.Cells
  widget.CellMin = (widget.options.CellMin / 100) * widget.options.Cells
  return widget
end

local function update(widget, options)
  widget.options = options
  widget.CellMax = (widget.options.CellMax / 100) * widget.options.Cells
  widget.CellMin = (widget.options.CellMin / 100) * widget.options.Cells
end

local function background(widget)
  widget.bt = getValue(widget.options.BattSensor)
  if widget.bt ~= 0 then
    batteryWarning(widget)
  end
end

local function refresh(widget, event, touchState)
  widget.bt = getValue(widget.options.BattSensor)
  if widget.bt ~= 0 then
    local steps = 0
    if widget.zone.h == 169 then
	  steps = math.floor(((144 / 100) * ((widget.bt - widget.CellMin) / ((widget.CellMax - widget.CellMin) / 100))))
	else
	  steps = math.floor(((167 / 100) * ((widget.bt - widget.CellMin) / ((widget.CellMax - widget.CellMin) / 100))))
	end
    if steps >= 0 and steps <= 167 and widget.zone.h == 42 then
      lcd.drawFilledRectangle(11, 3, steps, 36, GREEN)
    elseif steps >= 0 and steps <= 167 and widget.zone.h == 56 then
      lcd.drawFilledRectangle(11, 3, steps, 50, GREEN)
    elseif steps >= 0 and steps <= 167 and widget.zone.h == 84 then
      lcd.drawFilledRectangle(11, 3, steps, 78, GREEN)
    elseif steps >= 0 and steps <= 144 and widget.zone.h == 169 then
      lcd.drawFilledRectangle(3, 144 - steps + 16, 78, steps, GREEN)
    else
      batteryWarning(widget)
    end
    lcd.drawBitmap(widget.picture[widget.zone.h], 0, 0)
    if widget.zone.h == 169 then
      lcd.drawText(widget.zone.w * 0.70, widget.zone.h * 0.68, string.format("%.2fv", widget.bt / widget.options.Cells), CENTER + VCENTER + 0 + GREEN + SHADOWED)
      lcd.drawText(widget.zone.w * 0.70, widget.zone.h * 0.82, string.format("%.2fv", widget.bt), CENTER + VCENTER + DBLSIZE + GREEN + SHADOWED)
	else
      lcd.drawText(widget.zone.w / 2, widget.zone.h * 0.28, string.format("%.2fv", widget.bt / widget.options.Cells), CENTER + VCENTER + 0 + GREEN + SHADOWED)
      lcd.drawText(widget.zone.w / 2, widget.zone.h * 0.62, string.format("%.2fv", widget.bt), CENTER + VCENTER + MIDSIZE + GREEN + SHADOWED)
	end
  else
    lcd.drawBitmap(widget.picture[widget.zone.h], 0, 0)
	if widget.zone.h == 169 then
      lcd.drawText(widget.zone.w * 0.70, widget.zone.h * 0.68, string.format("%.2fv", widget.bt / widget.options.Cells), CENTER + VCENTER + 0 + COLOR_THEME_DISABLED + SHADOWED + BLINK)
      lcd.drawText(widget.zone.w * 0.70, widget.zone.h * 0.82, string.format("%.2fv", widget.bt), CENTER + VCENTER + MIDSIZE + COLOR_THEME_DISABLED + SHADOWED + BLINK)
	else
      lcd.drawText(widget.zone.w / 2, widget.zone.h * 0.28, string.format("%.2fv", widget.bt / widget.options.Cells), CENTER + VCENTER + 0 + COLOR_THEME_DISABLED + SHADOWED + BLINK)
      lcd.drawText(widget.zone.w / 2, widget.zone.h * 0.62, string.format("%.2fv", widget.bt), CENTER + VCENTER + MIDSIZE + COLOR_THEME_DISABLED + SHADOWED + BLINK)
	end
  end
end

return {
  name = version,
  options = options,
  create = create,
  update = update,
  refresh = refresh,
  background = background
}