---- #########################################################################
---- #                                                                       #
---- # Copyright (C) EdgeTX                                                  #
-----#                                                                       #
---- # License GPLv2: http://www.gnu.org/licenses/gpl-2.0.html               #
---- #                                                                       #
---- # This program is free software; you can redistribute it and/or modify  #
---- # it under the terms of the GNU General Public License version 2 as     #
---- # published by the Free Software Foundation.                            #
---- #                                                                       #
---- # This program is distributed in the hope that it will be useful        #
---- # but WITHOUT ANY WARRANTY; without even the implied warranty of        #
---- # MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         #
---- # GNU General Public License for more details.                          #
---- #                                                                       #
---- #########################################################################
chdir("/SCRIPTS/TOOLS/FrSky_Gyro_Suite/SRx_plus")

local isColor = (LCD_W == 480)

local app_ver = "v3.0.6"
local app_name = "FrSky_Gyro_Suite"

local IS_SIMULATOR = false -- updated in init()
local CommonFile = assert(loadfile("common.lua"))()
local Telemetry  = CommonFile.Telemetry


local CALI_OPERATION_TIMEOUT = 16 * 100 -- seconds  (100 ticks per second)
local PUSH_FRAME_TIMEOUT = 2 * 100 -- seconds (100 ticks per second)

local CALI_PAGE = { 0xB9, 0xD3 }  -- address for Gyro1, and Gyro2
local CALI_START_COMMAND = 0x01

local EXC_STATE_READY   = 0x00
local EXC_STATE_RUNNING = 0x01
local EXC_STATE_DONE    = 0x02

local CALI_STATE_INIT     = 0x00
local CALI_STATE_READ     = 0x01
local CALI_STATE_RECEIVE  = 0x02
local CALI_STATE_WRITE    = 0x03
local CALI_STATE_FINISHED = 0x04

local COL1_GYRO       = 1
local COL2_STEP       = 2
local COL3_TITLE      = 3
local COL4_HINT       = 4

local spacing         = 20
local font            = 0

local caliState = CALI_STATE_INIT
local caliError = false

local pages = {}
local parameters = {}
local page = 1


local finalTick = nil
local lastPushTick = nil

-- common
local function log(fmt, ...)
  print("[" .. app_name .. "]" .. string.format(fmt, ...))
end

-- Select the next or previous page
local function selectPage(step)
  page = 1 + ((page + step - 1 + #pages) % #pages)
  caliState = CALI_STATE_INIT
end

local function refreshNext(param)
  local gyroNo   = param[COL1_GYRO]
  local caliPage  = CALI_PAGE[gyroNo]
  local step = param[COL2_STEP]

  -- Calibration timeout
  if getTime() > finalTick then
    log("TimeOut!!!")
    caliState = CALI_STATE_FINISHED
    caliError = true
  end

  if caliState == CALI_STATE_WRITE then
    log("Write Start Command")
    local val = bit32.bor(step, bit32.lshift(CALI_START_COMMAND,8)) -- CCSS
    if Telemetry.telemetryWrite(caliPage, val) == true then
      caliState = CALI_STATE_READ
      lastPushTick = getTime() + PUSH_FRAME_TIMEOUT
    end
  elseif caliState == CALI_STATE_READ or (getTime() > lastPushTick) then
    log("Send Read Request")
    local page = bit32.bor(caliPage, bit32.lshift(step,8))
    if Telemetry.telemetryRead(page) == true then
      caliState = CALI_STATE_RECEIVE
      lastPushTick = getTime() + PUSH_FRAME_TIMEOUT
    end
  elseif caliState == CALI_STATE_RECEIVE then
    local value = Telemetry.telemetryPop()
    if value == nil then return end -- Return if no value??

    local fieldId,D1,D2 = Telemetry.parseValue(value)
    if fieldId ~= caliPage then return end --?? Return if not the data requested

    log("telementryPop Return valid data")
    local excStep = D1
    local excStepState = D2
    log("exeStep: %d, execStepState: %d", excStep,excStepState)
    -- Wrong step
    if excStep ~= step then return end -- Return on Wrong Step

    --lastPushTick = nil
    if excStepState == EXC_STATE_READY then
      caliState = CALI_STATE_WRITE
    elseif excStepState == EXC_STATE_RUNNING then
      caliState = CALI_STATE_READ
    elseif excStepState == EXC_STATE_DONE then
      caliState = CALI_STATE_FINISHED
      caliError = false
    end
  end
end

local function clibrationInProgress()
    return not ((caliState == CALI_STATE_INIT) or (caliState == CALI_STATE_FINISHED))
end

local function drawScreenTitle(title, page, pages)
  if (isColor) then
    lcd.drawFilledRectangle(0, 0, LCD_W, 30, TITLE_BGCOLOR)
    lcd.drawText(1, 5, title, MENU_TITLE_COLOR)
    --lcd.drawText(LCD_W-40, 5, page.."/"..pages, MENU_TITLE_COLOR)
  else
    lcd.drawText(1, 0, title, INVERS + font)
  end
end

local function my_drawText(x,y,msg, font)
  if (isColor) then
    lcd.drawText(x,y,msg,font)
  else
    --Split messages with \n 
    local i = 0
    for line in string.gmatch(msg, "[^\r\n]+") do
      lcd.drawText(x,y+(i*spacing),line,font)
      i=i+1
    end
  end
end


local function runCalibration(param, event)
  lcd.clear()
  drawScreenTitle(param[COL3_TITLE], page, #pages)

  if (clibrationInProgress()) then
    refreshNext(param)
  end

  if (caliState == CALI_STATE_INIT) then
    my_drawText(1, spacing * 2, param[COL4_HINT], font)
  elseif (caliState == CALI_STATE_FINISHED) then
    if (caliError) then
      my_drawText(1, spacing * 2, "Calibration failed!\nPlease check the connection state\nand make sure Gyro is Enabled\nPress [ENTER] to exit", font)
    else
      my_drawText(1, spacing * 2, "Calibration finished.\nPress [ENTER] to exit", font)
    end
  else
    my_drawText(1, spacing * 2, "Please wait until calibration is finished ...", font)
  end

  if (event == EVT_VIRTUAL_EXIT and not clibrationInProgress()) then
    page = 1 -- return to main menu
    caliState = CALI_STATE_INIT
  elseif event == EVT_VIRTUAL_ENTER and caliState == CALI_STATE_FINISHED then
    page = 1 -- return to main menu
    caliState = CALI_STATE_INIT
  elseif event == EVT_VIRTUAL_ENTER and caliState == CALI_STATE_INIT then
    -- start Calibration
    lastPushTick = getTime() + PUSH_FRAME_TIMEOUT
    finalTick    = getTime() + CALI_OPERATION_TIMEOUT
    caliState    = CALI_STATE_WRITE
  end
  return 0
end

local introMenu = {
  pos = 1,
  menu = {
      -- Menu, Page
      {"Level Cal    (Gyro 1)", 2},
      {"Stick Center (Gyro 1)", 3},
      {"Stick Range  (Gyro 1)", 4},
      {"Level Cal    (Gyro 2)", 5},
      {"Stick Center (Gyro 2)", 6},
      {"Stick Range  (Gyro 2)", 7},
  }
}


local function runIntroPage(param, event)
  lcd.clear()
  drawScreenTitle(param[COL3_TITLE], page, #pages)

  local startSpacing = 0
  if (isColor) then
    startSpacing = spacing
  end

  for iParam=1, #introMenu.menu do
    -- set y draw coord
    local y = startSpacing + (iParam) * spacing
    local x = 1

    -- highlight selected parameter
    local attr = (introMenu.pos==iParam) and INVERS or 0

    local title = introMenu.menu[iParam][1] -- Title
    lcd.drawText (x, y, title, attr + font)
  end

  if event == EVT_VIRTUAL_PREV then
    if (introMenu.pos>1) then introMenu.pos = introMenu.pos - 1 end
  elseif event == EVT_VIRTUAL_NEXT then
    if (introMenu.pos < #introMenu.menu) then introMenu.pos = introMenu.pos + 1 end
  elseif event == EVT_VIRTUAL_ENTER then
      page = introMenu.menu[introMenu.pos][2]
  elseif (event == EVT_VIRTUAL_EXIT) then
    return 2
  end
  return 0
end

-- Init
local function init()
  page = 1
  pages = {
      runIntroPage,
      runCalibration,
      runCalibration,
      runCalibration,
      runCalibration,
      runCalibration,
      runCalibration
  }

  if (not isColor) then
    spacing = 9
    font    = SMLSIZE
  end

  parameters = {
     { 0, 0, "SRx PreCalibration ("..app_ver..")",
     },
     { 1, 1, "Level Cali. (Gyro 1)",
                --"Horizontal Calibration\nis about to begin.\n"..
                "Please place the model in\na level position,\n" ..
                "then press [ENTER] to start."
     },
     { 1, 2, "Stick Center (Gyro 1)",
                --"Stick center calibration is\nabout to begin.\n" ..
                "Please set the stick to the\ncenter position,\n" ..
                "then press [ENTER] to start."
    },
    { 1, 3, "Stick Range  (Gyro 1)",
                --"Stick range calibration is\nabout to begin.\n" ..
                "After pressing [ENTER],\nplease move the stick to\n" ..
                "its full range in all\ndirections to calibrate.",
    },
    { 2, 1, "Level Cali. (Gyro 2, ACCESS only)",
              --"Horizontal Calibration\nis about to begin.\n"..
              "Please place the model in\na level position,\n" ..
              "then press [ENTER] to start."
    },
    { 2, 2, "Stick Center  (Gyro 2, ACCESS only)",
              --"Stick center calibration is\nabout to begin.\n" ..
              "Please set the stick to the\ncenter position,\n" ..
              "then press [ENTER] to start."
    },
    { 2, 3, "Stick Range  (Gyro 2, ACCESS only)",
              --"Stick range calibration is\nabout to begin.\n" ..
              "After pressing [ENTER],\nplease move the stick to\n" ..
              "its full range in all\ndirections to calibrate.",
    }
  }

  local _, rv = getVersion()
  IS_SIMULATOR =  string.sub(rv, -5) == "-simu"
  if IS_SIMULATOR then
    local SimFile = assert(loadfile("simSR10plus.lua"))()
    -- Override telemetry object for a simulated one
    Telemetry = SimFile.Telemetry
  end
end

-- Main
local function run(event)
  if event == nil then
    error("Cannot be run as a model script!")
    return 2
  end

  local result = pages[page](parameters[page],event)
  return result
end

return { init=init, run=run }
