-- TNS|FrSky Gyro S6R S8R SR8+ SR10+|TNE

local function run()
  return "/SCRIPTS/TOOLS/FrSky_Gyro_Suite/main.lua"
end

return { run = run }
