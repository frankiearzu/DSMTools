local toolName = "TNS|DSM Frwd Prog v0.53 MIN-MEM|TNE"

---- #########################################################################
---- #                                                                       #
---- # Copyright (C) OpenTX                                                  #
-----#                                                                       #
---- # License GPLv2: http://www.gnu.org/licenses/gpl-2.0.html               #
---- #                                                                       #
---- # This program is free software; you can redistribute it and/or modify  #
---- # it under the terms of the GNU General Public License version 2 as     #
---- # published by the Free Software Foundation.                            #
---- #                                                                       #
---- # This program is distributed in the hope that it will be useful        #
---- # but WITHOUT ANY WARRANTY; without even the implied warranty of        #
---- # MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         #
---- # GNU General Public License for more details.                          #
---- #                                                                       #
---- #########################################################################


--###############################################################################
-- Multi buffer for DSM description
-- Multi_Buffer[0..2]=="DSM" -> Lua script is running
-- Multi_Buffer[3]==0x70+len -> TX to RX data ready to be sent
-- Multi_Buffer[4..9]=6 bytes of TX to RX data
-- Multi_Buffer[10..25]=16 bytes of RX to TX data
--
-- To start operation:
--   Write 0x00 at address 3
--   Write 0x00 at address 10
--   Write "DSM" at address 0..2
--###############################################################################

local VERSION             = "v0.54"
local LANGUAGE            = "en"
local DSMLIB_PATH         = "/SCRIPTS/TOOLS/DSMLIB/"

local LOG_FILE            = "/LOGS/dsm_min_log.txt"
local MSG_FILE            = DSMLIB_PATH.."msg_" .. LANGUAGE .. ".txt"
local MSG_FILE_MIN        = DSMLIB_PATH.."msg_MIN_" .. LANGUAGE .. ".txt"

local RX_VERSION, WAIT_CMD, MENU_TITLE, MENU_TX_INFO, MENU_LINES, MENU_VALUES = 0, 1, 2, 3, 4, 5
local VALUE_CHANGING, VALUE_CHANGING_WAIT, VALUE_CHANGED, EXIT, EXIT_DONE     = 6, 7, 8, 9, 10

local MENU, LIST_MENU_NOCHANGING, LIST_MENU1, LIST_MENU2, VALUE_NOCHANGING    = 0x1C, 0x6C, 0x0C, 0x4C, 0x60
local Phase                                                                   = RX_VERSION
local Waiting_RX                                                              = 0

local Text                                                                    = {}
local List_Text                                                               = {}
local List_Text_Img                                                           = {}
local Flight_Mode                                                             = { [0] = "Flight Mode" }

local RxName                                                                  = {}
local InactivityTime                                                          = 0
local Value_Changed                                                           = 0
local originalValue                                                           = 0

local ctx                                                                     = {
  SelLine = 0,      -- Current Selected Line
  EditLine = nil,   -- Current Editing Line
  CurLine = -1,     -- Current Line Requested/Parsed via h message protocol
  isReset = false   -- false when starting from scracts, true when starting from Reset
}


local Menu                = { MenuId = 0, Text = "", TextId = 0, PrevId = 0, NextId = 0, BackId = 0 }
local MenuLines           = {}
local RX                  = { Name = "", Version = "" }

local logFile             = nil
local logCount            = 0

local LCD_X_LINE_TITLE    = 0
local LCD_X_LINE_VALUE    = 75

local LCD_W_BUTTONS       = 19
local LCD_H_BUTTONS       = 10
local LCD_X_RIGHT_BUTTONS = 128 - LCD_W_BUTTONS - 1

local LCD_Y_LINE_HEIGHT   = 7
local LCD_Y_LOWER_BUTTONS = (8 * LCD_Y_LINE_HEIGHT) + 2

local function LOG_open()
  logFile = io.open(LOG_FILE, "w")   -- Truncate Log File
end

local function LOG_write(...)
  if (logFile == nil) then LOG_open() end
  local str = string.format(...)
  io.write(logFile, str)

  print(str)

  if (logCount > 10) then   -- Close an re-open the file
    io.close(logFile)
    logFile = io.open(LOG_FILE, "a")
    logCount = 0
  end
end

local function LOG_close()
  if (logFile ~= nil) then io.close(logFile) end
end

---------------- DSM Values <-> Int16 Manipulation --------------------------------------------------------

local function int16_LSB(number) -- Less Significat byte
  local r, x = bit32.band(number, 0xFF)
  return r
end

local function int16_MSB(number) -- Most signifcant byte
  return bit32.rshift(number, 8)
end

local function Dsm_to_Int16(lsb, msb) -- Componse an Int16 value
  return bit32.lshift(msb, 8) + lsb
end

local function Dsm_to_SInt16(lsb, msb) -- Componse a SIGNED Int16 value
  local value = bit32.lshift(msb, 8) + lsb
  if value >= 0x8000 then             -- Negative value??
    return value - 0x10000
  end
  return value
end

local function sInt16ToDsm(value) -- Convent to SIGNED DSM Value
  if value < 0 then
    value = 0x10000 + value
  end
  return value
end

------------------------------------------------------------------------------------------------------------
local function Get_Text(index)
  local out = Text[index]
  if out == nil then -- unknown...
    out = "Unknown_" .. string.format("%X", index)
  end
  return out
end

local function Get_Text_Value(index)
  local out = List_Text[index]
  if out == nil then  -- unknown...
    out = Get_Text(index)
  end
  return out
end
------------------------------------------------------------------------------------------------------------
local function Get_RxName(index)
  local out = RxName[index]
  if out == nil then -- unknown...
    out = "Unknown_" .. string.format("%X", index)
  end
  return out
end
------------------------------------------------------------------------------------------------------------
local function DSM_Release()
  multiBuffer(0, 0)
  Phase = EXIT_DONE
  LOG_close()
end
------------------------------------------------------------------------------------------------------------
local function DSM_Send(...)
  local arg = { ... }
  for i = 1, #arg do
    multiBuffer(3 + i, arg[i])
  end
  multiBuffer(3, 0x70 + #arg)
end
------------------------------------------------------------------------------------------------------------

function ChangePhase(newPhase)
  Phase = newPhase
  Waiting_RX = 0
end

local function Value_Add(dir)
  local line = MenuLines[ctx.SelLine]

  Speed = getRotEncSpeed()
  if Speed == ROTENC_MIDSPEED then
    line.Val = line.Val + (5 * dir)
  elseif Speed == ROTENC_HIGHSPEED then
    line.Val = line.Val + (15 * dir)
  else
    line.Val = line.Val + dir
  end

  if line.Val > line.Max then
    line.Val = line.Max
  elseif line.Val < line.Min then
    line.Val = line.Min
  end
  --if MenuLines[ctx.SelLine].Type ~= LIST_MENU_NOCHANGING then
  ChangePhase(VALUE_CHANGING)
  Value_Changed = 0
  --end
end
------------------------------------------------------------------------------------------------------------

local function GotoMenu(menuId, lastSelectedLine)
  Menu.MenuId = menuId
  ctx.SelLine = lastSelectedLine
  -- Request to load the menu Again
  ChangePhase(MENU_TITLE)
end

local function isSelectable(line)
  if (line.TextId == 0x00CD) then return true end                          -- Exceptiom: Level model and capture attitude
  if (line.Type == MENU and line.ValId == line.MenuId) then return false end -- Menu to same page
  return line.Type ~= 0 and line.TextId < 0x8000                           -- Not Flight Mode
end

local function DSM_Menu(event)
  if event == EVT_VIRTUAL_EXIT then
    if Phase == RX_VERSION then
      DSM_Release()
    else
      if ctx.EditLine ~= nil then   -- Editing a Line, need to  restore original value
        MenuLines[ctx.EditLine].Val = originalValue
        event = EVT_VIRTUAL_ENTER
      else
        ChangePhase(EXIT)
      end
    end
  end

  if Phase == RX_VERSION then return end -- nothing else to do 

  if event == EVT_VIRTUAL_NEXT then
    if ctx.EditLine ~= nil then
      Value_Add(1)
    else
      -- not changing a value

      if ctx.SelLine < 7 then
        local num = ctx.SelLine
        for i = ctx.SelLine + 1, 6, 1 do
          local line = MenuLines[i]
          if isSelectable(line) then
            ctx.SelLine = i
            break
          end
        end
        if num == ctx.SelLine then       -- No Selectable Line
          if Menu.NextId ~= 0 then       -- Next
            ctx.SelLine = 7
          elseif Menu.PrevId ~= 0 then   -- Prev
            ctx.SelLine = 8
          end
        end
      elseif Menu.PrevId ~= 0 then   -- Prev
        ctx.SelLine = 8
      end
    end
  elseif event == EVT_VIRTUAL_PREV then
    if ctx.EditLine ~= nil then -- In Edit Mode
      Value_Add(-1)
    else
      if ctx.SelLine == 8 and Menu.NextId ~= 0 then
        ctx.SelLine = 7
      elseif ctx.SelLine > 0 then
        if ctx.SelLine > 6 then
          ctx.SelLine = 7
        end
        local num = ctx.SelLine
        for i = ctx.SelLine - 1, 0, -1 do
          local line = MenuLines[i]
          if isSelectable(line) then
            ctx.SelLine = i
            break
          end
        end
        if num == ctx.SelLine then   -- No Selectable Line
          if (Menu.BackId > 0) then ctx.SelLine = -1 end
        end
      else
        ctx.SelLine = -1   -- Back
      end
    end
  elseif event == EVT_VIRTUAL_ENTER_LONG then
    if ctx.EditLine ~= nil then
      -- reset the value to default
      --if MenuLines[ctx.SelLine].Type ~= LIST_MENU_NOCHANGING then
      MenuLines[ctx.SelLine].Val = MenuLines[ctx.SelLine].Def
      ChangePhase(VALUE_CHANGING)
      Value_Changed = 0
      --end
    end
  elseif event == EVT_VIRTUAL_ENTER then
    if ctx.SelLine == -1 then    -- Back
      GotoMenu(Menu.BackId, 0x80)
    elseif ctx.SelLine == 7 then -- Next
      GotoMenu(Menu.NextId, 0x82)
    elseif ctx.SelLine == 8 then -- Prev
      GotoMenu(Menu.PrevId, 0x81)
    elseif ctx.SelLine >= 0 and MenuLines[ctx.SelLine].Type == MENU then
      GotoMenu(MenuLines[ctx.SelLine].ValId, ctx.SelLine)  -- ValId is the next menu
    else
      -- value entry
      if ctx.EditLine ~= nil then
        ctx.EditLine = nil   -- Done Editting
        Value_Changed = 0
        ChangePhase(VALUE_CHANGED)
      else   -- Start Editing
        ctx.EditLine = ctx.SelLine
        originalValue = MenuLines[ctx.SelLine].Val
        ChangePhase(VALUE_CHANGING_WAIT)
      end
    end
  end
end
------------------------------------------------------------------------------------------------------------
local function DSM_SendRequest()
  --LOG_write("DSM_SendRequest  Phase=%d\n",Phase)
  -- Need to send a request
  if Phase == RX_VERSION then   -- request RX version
    DSM_Send(0x11, 0x06, 0x00, 0x14, 0x00, 0x00)
    LOG_write("GetVersion()\n")
  elseif Phase == WAIT_CMD then     -- keep connection open
    DSM_Send(0x00, 0x04, 0x00, 0x00)
  elseif Phase == MENU_TITLE then     -- request menu title
    local menuId = Menu.MenuId
    if menuId == 0 then
      DSM_Send(0x12, 0x06, 0x00, 0x14, 0x00, 0x00) -- first menu only
    else
      DSM_Send(0x16, 0x06, int16_MSB(menuId), int16_LSB(menuId), 0x00, ctx.SelLine)
      if (menuId == 0x0001) then     -- Executed Save&Reset menu
        LOG_write("Save&Reset RX\n")
        Phase = RX_VERSION
        ctx.isReset = true
        Menu.MenuId = 0
      end
    end
    LOG_write("GetMenu(M=0x%04X,L=%d)\n", menuId, ctx.SelLine)
  elseif Phase == MENU_TX_INFO then                                             -- TX Info
    LOG_write("TXInfoResp: L=%d\n", ctx.CurLine)
    local last_byte = { [0] = 0x40, 0x01, 0x02, 0x04, 0x00, 0x00 }              -- Channel Function (Thr, Ail, Ele, Rud)...
    DSM_Send(0x20, 0x06, ctx.CurLine, ctx.CurLine, 0x00, last_byte[ctx.CurLine]) -- line X
  elseif Phase == MENU_LINES then                                               -- request menu lines
    local menuId = Menu.MenuId

    if ctx.CurLine == -1 then
      DSM_Send(0x13, 0x04, int16_MSB(menuId), int16_LSB(menuId))                    -- line 0
    else
      DSM_Send(0x14, 0x06, int16_MSB(menuId), int16_LSB(menuId), 0x00, ctx.CurLine) -- line X
    end
    LOG_write("GetLines(LastLine=%d)\n", ctx.CurLine)
  elseif Phase == MENU_VALUES then     -- request menu values
    local menuId = Menu.MenuId
    local valId  = MenuLines[ctx.CurLine].ValId
    DSM_Send(0x15, 0x06,
      int16_MSB(menuId), int16_LSB(menuId),
      int16_MSB(valId), int16_LSB(valId))        -- line X
    LOG_write("GetValues(LastVId=0x%04X)\n", valId)
  elseif Phase == VALUE_CHANGING then     -- send value
    local valId = MenuLines[ctx.SelLine].ValId
    if Value_Changed == 0 then
      local value = sInt16ToDsm(MenuLines[ctx.SelLine].Val)

      DSM_Send(0x18, 0x06,
        int16_MSB(valId), int16_LSB(valId),
        int16_MSB(value), int16_LSB(value))        -- send current values
      Value_Changed = 1
      Waiting_RX = 0
      LOG_write("ChangeValue(VId=0x%04X,Val=%d)\n", valId, value)
    else
      -- Validate Value
      DSM_Send(0x19, 0x04, int16_MSB(valId), int16_LSB(valId))
      Value_Changed = 0
      Phase = VALUE_CHANGING_WAIT
      LOG_write("ValidateValue(VId=0x%04X)\n", valId)
    end
  elseif Phase == VALUE_CHANGED then     -- EditLineEND
    DSM_Send(0x1B, 0x04, 0x00, int16_LSB(ctx.SelLine))
    Value_Changed = 0
    Phase = WAIT_CMD
    LOG_write("EditLineEND(L=%d)\n", ctx.SelLine)
    --end
  elseif Phase == VALUE_CHANGING_WAIT then
    -- Value Changing Wait
    DSM_Send(0x1A, 0x04, 0x00, int16_LSB(ctx.SelLine))
    LOG_write("EditLineBEGIN(L=%d)\n", ctx.SelLine)
  elseif Phase == EXIT then
    DSM_Send(0x1F, 0x02, 0xAA)
  end
end

local function DSM_ProcessResponse()
  local cmd = multiBuffer(11)
  -- LOG_write("DSM_ProcessResponse BEGIN: Cmd=%x\n",cmd)
  if cmd == 0x01 then    -- read version
    RX.Name = Get_RxName(multiBuffer(13))
    RX.Version = multiBuffer(14) .. "." .. multiBuffer(15) .. "." .. multiBuffer(16)
    ctx.isReset = false     -- no longer resetting
    Phase = MENU_TITLE
    LOG_write("Version: %s %s\n", RX.Name, RX.Version)
  elseif cmd == 0x02 then     -- read menu title
    local menu  = Menu

    menu.MenuId = Dsm_to_Int16(multiBuffer(12), multiBuffer(13))
    menu.TextId = Dsm_to_Int16(multiBuffer(14), multiBuffer(15))
    menu.Text   = Get_Text(menu.TextId)
    menu.PrevId = Dsm_to_Int16(multiBuffer(16), multiBuffer(17))
    menu.NextId = Dsm_to_Int16(multiBuffer(18), multiBuffer(19))
    menu.BackId = Dsm_to_Int16(multiBuffer(20), multiBuffer(21))

    for i = 0, 6 do     -- clear menu
      MenuLines[i] = { MenuId = 0, Type = 0, TextId = 0, ValId = 0, Min = 0, Max = 0, Def = 0, Val = nil, Unit, Step }
    end
    ctx.CurLine = -1
    ctx.SelLine = -1     -- highlight Back

    LOG_write("Menu: Mid=0x%04X  \"%s\"\n", menu.MenuId, menu.Text)

    if (menu.MenuId == 0x0001) then     -- Still in RESETTING MENU???
      menu.MenuId = 0
      Phase = RX_VERSION
    else
      Phase = MENU_LINES
    end
  elseif cmd == 0x03 then     -- read menu lines
    local i      = multiBuffer(14)
    local type   = multiBuffer(15)
    local line   = MenuLines[i]

    ctx.CurLine  = i

    line.lineNum = i
    line.MenuId  = Dsm_to_Int16(multiBuffer(12), multiBuffer(13))
    line.Type    = type
    line.TextId  = Dsm_to_Int16(multiBuffer(16), multiBuffer(17))
    line.Text    = Get_Text(line.TextId)
    line.ValId   = Dsm_to_Int16(multiBuffer(18), multiBuffer(19))

    -- Singed int values
    line.Min     = Dsm_to_SInt16(multiBuffer(20), multiBuffer(21))
    line.Max     = Dsm_to_SInt16(multiBuffer(22), multiBuffer(23))
    line.Def     = Dsm_to_SInt16(multiBuffer(24), multiBuffer(25))

    if ctx.SelLine == -1 and isSelectable(line) then     -- Auto select first line of the menu
      ctx.SelLine = ctx.CurLine
    end

    if line.Type == MENU then
      -- nothing to do on menu entries
    elseif line.Type == LIST_MENU_NOCHANGING or line.Type == LIST_MENU1 or line.Type == LIST_MENU2 then
      line.Val = nil                     --line.Def - line.Min -- use default value not sure if needed
      line.Def = line.Min                -- pointer to the start of the list in Text
      line.Max = line.Max - line.Min     -- max index
      line.Min = 0                       -- min index
    else                                 -- default to numerical value
      line.Val = nil                     --line.Def -- use default value not sure if needed
    end

    LOG_write("Line: #%d Vid=0x%04X  \"%s\"\n", line.lineNum, line.ValId, line.Text)
    Phase = MENU_LINES
  elseif cmd == 0x04 then     -- read menu values
    --ex: 0x09 0x04 0x53 0x10 0x00 0x10 0x00 0x00 0x00 0x00 0x00 0x00 0x00 0x00 0x00 0x00
    --              Menu MeId line VaId Value
    --ex: 0x09 0x04 0x61 0x10 0x02 0x10 0x01 0x00 0x00 0x00 0x00 0x00 0x00 0x00 0x00 0x00
    -- Identify the line and update the value
    local valId = Dsm_to_Int16(multiBuffer(14), multiBuffer(15))
    local value = Dsm_to_SInt16(multiBuffer(16), multiBuffer(17))     --Signed int

    local updatedLine = nil
    for i = 0, 6 do     -- Find the menu line for this value
      local line = MenuLines[i]
      if line.Type ~= 0 then
        if line.Type ~= MENU and line.ValId == valId then         -- identifier of ValueId stored in the line
          line.Val = value
          ctx.CurLine = i
          updatedLine = line

          local valueTxt = value
          if line.Type == LIST_MENU_NOCHANGING or line.Type == LIST_MENU1 or line.Type == LIST_MENU2 then
            valueTxt = Get_Text_Value(line.Def + value) .. "  [" .. value .. "]"
          end

          LOG_write("Update Value: #%d  VId=0x%04X Value=%s\n", i, valId, valueTxt)
          break
        end
      end
    end

    if (updatedLine == nil) then
      LOG_write("Cannot Find Line for ValueId=%x\n", valId)
    end
    Phase = MENU_VALUES
  elseif cmd == 0x05 then    -- Request TX channel info
    ctx.CurLine = multiBuffer(12)
    Phase = MENU_TX_INFO
  elseif cmd == 0xA7 then     -- answer to EXIT command
    DSM_Release()
    LOG_close()
  elseif cmd == 0x00 and Phase == VALUE_CHANGING then
    Phase = VALUE_CHANGING_WAIT
  end

  --LOG_write("DSM_ProcessResponse END: Cmd=%x\n",cmd)
  return cmd
end


local function DSM_Send_Receive()
  if Waiting_RX == 0 then
    Waiting_RX = 1
    DSM_SendRequest()
    multiBuffer(10, 0x00);
    InactivityTime = getTime() + 200 -- Reset Inactivity timeout
    -- -- -- -- -- -- -- -- -- -- -- -- receive part -- -- -- -- -- -- -- -- -- -- -- -- --
  elseif multiBuffer(10) == 0x09 then
    local cmd = DSM_ProcessResponse()
    -- Data processed
    multiBuffer(10, 0x00)
    if (cmd > 0x00) then -- Any non NULL response
      -- Only change to SEND mode if we received a valid response  (Ignore NULL Responses, that are really heartbeat i most cases)
      Waiting_RX = 0
      InactivityTime = getTime() + 200   -- Reset Inactivity timeout
    end
  else                                   -- No Send or Receive,
    -- Check if enouth time has passed from last transmit/receive activity
    if getTime() > InactivityTime then
      InactivityTime = getTime() + 200
      Waiting_RX = 0   -- Switch to Send mode to send heartbeat

      if Phase == EXIT then
        DSM_Release()
      end

      if Phase ~= RX_VERSION and Phase ~= VALUE_CHANGING_WAIT then
        Phase = WAIT_CMD
      end
    end
  end
end
------------------------------------------------------------------------------------------------------------

local function showBitmap(x, y, imgDesc)
  local f = string.gmatch(imgDesc, '([^%|]+)')   -- Iterator over values split by '|'
  local imgName, imgMsg = f(), f()

  f = string.gmatch(imgMsg or "", '([^%:]+)')   -- Iterator over values split by ':'
  local p1, p2 = f(), f()

  lcd.drawText(x, y, p1 or "", SMLSIZE)                     -- Alternate Image MSG
  lcd.drawText(x, y + LCD_Y_LINE_HEIGHT, p2 or "", SMLSIZE) -- Alternate Image MSG
end


local function drawButton(x, y, text, active)
  local attr = SMLSIZE
  if (active) then attr = attr + INVERS end
  lcd.drawText(x, y, text, attr)
end

local ver_rx_count = 0

local function DSM_Display()
  lcd.clear()
  --Draw RX Menu
  if Phase == RX_VERSION then
    lcd.drawText(1, 0, "DSM Frwd Prog "..VERSION, INVERS)
    if (ctx.isReset) then
      lcd.drawText(0, 3 * LCD_Y_LINE_HEIGHT, Get_Text(0x301), BLINK) -- Waiting for Reset
    else
      lcd.drawText(0, 3 * LCD_Y_LINE_HEIGHT, Get_Text(0x300), BLINK) -- No compatible DSM RX...
    end
  else

    if (ver_rx_count < 100) then
        lcd.drawText(40, LCD_Y_LOWER_BUTTONS, RX.Name .. " v" .. RX.Version, SMLSIZE) -- display RX info
        ver_rx_count = ver_rx_count + 1
    else
        lcd.drawText(30, LCD_Y_LOWER_BUTTONS, "Frwd Prog "..VERSION, SMLSIZE) -- display Program version
        ver_rx_count = ver_rx_count + 1
        if (ver_rx_count > 200) then ver_rx_count=0 end
    end

    if Menu.MenuId == 0 then return end; -- No Title yet

    lcd.drawText(1, 0, Menu.Text, SMLSIZE + INVERS)

    local y = LCD_Y_LINE_HEIGHT + 2
    for i = 0, 6 do
      local attrib = SMLSIZE
      if (i == ctx.SelLine) then attrib = attrib + INVERS end     -- Selected Line

      local line = MenuLines[i]

      if line ~= nil and line.Type ~= 0 then
        local heading = Get_Text(line.TextId)

        if (line.TextId >= 0x8000) then     -- Flight mode
          heading = "   " .. Flight_Mode[0] .. " " 
          if (line.Val==nil) then heading = heading .. "--" else heading = heading .. ((line.Val or 0) + 1) end
        else
          local text = "-"
          if line.Type ~= MENU then       -- list/value
            if line.Val ~= nil then
              if line.Type == LIST_MENU_NOCHANGING or line.Type == LIST_MENU1 or line.Type == LIST_MENU2 then
                local textId = line.Val + line.Def
                text = Get_Text_Value(textId)

                local imgDesc = List_Text_Img[textId]

                if (imgDesc and i == ctx.SelLine) then             -- Optional Image and Msg for selected value
                  showBitmap(0, 20, imgDesc)
                end
              elseif (line.Min == 0 and line.Max == 100) or (line.Min == -100 and line.Max == 100) or
                  (line.Min == 0 and line.Max == 150) or (line.Min == -150 and line.Max == 150) then
                text = line.Val .. " %"
              elseif (line.Type == 0xE0) then -- Degress
                text = line.Val .. " @"
              else
                text = line.Val
              end
            end -- if is Value

            if (ctx.EditLine == i) then  -- Editing a Line
              attrib = BLINK + INVERS + SMLSIZE
            end
            lcd.drawText(128, y, text, attrib + RIGHT) -- display value
            attrib = SMLSIZE
          end
        end                                     -- Flight mode
        lcd.drawText(0, y, heading, attrib)     -- display text
      end
      y = y + LCD_Y_LINE_HEIGHT
    end     -- for

    if Menu.BackId ~= 0 then
      drawButton(LCD_X_RIGHT_BUTTONS, 0, "Back", ctx.SelLine == -1)
    end

    if Menu.NextId ~= 0 then
      drawButton(LCD_X_RIGHT_BUTTONS, LCD_Y_LOWER_BUTTONS, "Next", ctx.SelLine == 7)
    end

    if Menu.PrevId ~= 0 then
      drawButton(0, LCD_Y_LOWER_BUTTONS, "Prev", ctx.SelLine == 8)
    end
  end
end

local function load_msg_from_file(fileName, mem, Text, List_Text, List_Text_Img, RxName, Flight_Mode)
  local function rtrim(s)
    local n = string.len(s)
    while n > 0 and string.find(s, "^%s", n) do n = n - 1 end
    return string.sub(s, 1, n)
  end

  --print(string.format("Loading messages from [%s]",fileName))
  local dataFile = io.open(fileName, "r")   -- read File
  -- cannot read file???
  assert(dataFile, "Cannot load Message file:" .. fileName)

  local data = io.read(dataFile, mem * 1024) -- read up to 10k characters (newline char also counts!)

  local lineNo = 0
  for line in string.gmatch(data, "[^\r\n]+") do
    lineNo = lineNo + 1
    --print(string.format("Line [%d]: %s",lineNo,line))

    -- Remove Comments
    local s = string.find(line, "--", 1, true)
    if (s ~= nil) then
      line = string.sub(line, 1, s - 1)
    end

    line = rtrim(line)

    if (string.len(line) > 0) then
      local a, b, c = string.match(line, "%s*(%a*)%s*|%s*(%w*)%s*|(.*)%s*")
      --print(string.format("[%s] [%s] [%s]",a,b,c))
      if (a ~= nil) then
        local index = tonumber(b)

        if (index == nil) then
          assert(false, string.format("%s:%d: Invalid Hex num [%s]", fileName, lineNo, b))
        elseif (a == "T") then
          Text[index] = c
        elseif (a == "LT") then
          List_Text[index] = c
        elseif (a == "LI") then
          List_Text_Img[index] = c
        elseif (a == "FM") then
          Flight_Mode[0] = c
        elseif (a == "RX") then
          RxName[index] = c
        else
          assert(false, string.format("%s:%d: Invalid Line Type [%s]", fileName, lineNo, a))
        end
      end
    end
  end

  --print(string.format("Loaded [%d] messages",lineNo))
  data = nil
  io.close(dataFile)
end

local function clean_msg(Text, Flight_Mode)
  -- Clean the line of special markers that are only used in color vesion
  for i = 0, 0x0300 do
      local pos=0
      local c = Text[i]
      if (c~=nil) then
        c, pos = string.gsub(c, "/b$", "")
        c, pos = string.gsub(c, "/c$", "")
        c, pos = string.gsub(c, "/r$", "")
        c, pos = string.gsub(c, "/p$", "")
        c, pos = string.gsub(c, "/m$", "")
        Text[i] = c
      end
  end

  for i = 0, #Flight_Mode do
    -- Clean the line of special markers that are only used in color vesion
    local pos=0
    local c = Flight_Mode[i]
    if (c~=nil) then
      c, pos = string.gsub(c, "/b$", "")
      c, pos = string.gsub(c, "/c$", "")
      c, pos = string.gsub(c, "/r$", "")
      c, pos = string.gsub(c, "/p$", "")
      c, pos = string.gsub(c, "/m$", "")
      Flight_Mode[i] = c
    end
end
end

------------------------------------------------------------------------------------------------------------
-- Init
local function DSM_Init()
  --Set protocol to talk to
  multiBuffer(0, string.byte('D'))
  --test if value has been written
  if multiBuffer(0) ~= string.byte('D') then
    error("Not enough memory!")
    return 2
  end

  LOG_open()
  LOG_write("-------- NEW SESSION --------------------\n")

  --Init TX buffer
  multiBuffer(3, 0x00)
  --Init RX buffer
  multiBuffer(10, 0x00)
  --Init telemetry
  multiBuffer(0, string.byte('D'))
  multiBuffer(1, string.byte('S'))
  multiBuffer(2, string.byte('M'))

  collectgarbage("collect")
  load_msg_from_file(MSG_FILE, 10, Text, List_Text, List_Text_Img, RxName, Flight_Mode)
  collectgarbage("collect")
  load_msg_from_file(MSG_FILE_MIN, 4, Text, List_Text, List_Text_Img, RxName, Flight_Mode)
  collectgarbage("collect")
  clean_msg(Text,Flight_Mode)
end
------------------------------------------------------------------------------------------------------------
-- Main
local function DSM_Run(event)
  if event == nil then
    error("Cannot be run as a model script!")
    return 2
  else
    DSM_Display()
    DSM_Menu(event)
    DSM_Send_Receive()
  end
  if Phase == EXIT_DONE then
    return 2
  else
    return 0
  end
end

return { init = DSM_Init, run = DSM_Run }
